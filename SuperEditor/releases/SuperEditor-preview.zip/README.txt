SuperEditor development preview
===================================

SuperEditor is a standalone PETSCII Markdown-lite editor for the Commodore 64,
written in 6510 assembly. This is a development preview, not a finished ReadyOS
application.

Requirements
------------
* PAL or NTSC Commodore 64 or compatible emulator
* 1581/D81 support on device 8
* REU enabled; 2 MiB supports the tested small-document workflow, while 16 MiB
  is recommended for larger documents and the full feature set

Start
-----
1. Attach SUPEREDITOR.D81 as an unpartitioned 1581 disk on device 8.
2. Enable the REU.
3. Enter:

   LOAD"SUPEREDITOR",8,1
   RUN

F1 opens menus, F6 opens the three-page help, F7 opens the typed command line,
and F8 cycles 40, 60, 80-column and GEOS-font views. CTRL-O opens a file and
CTRL-S saves. Files are raw PETSCII SEQ text with CR line endings.

The disk must remain mounted because editor modules and the data-only GEOS font
pack are loaded from it. The archive does not contain a GEOS system disk,
applications, executable font software, test probes or diagnostic artifacts.

Complete guide
--------------
https://readyos-c64.github.io/UltimateExperiments/supereditor/USER_GUIDE.html

Source and build instructions
-----------------------------
https://github.com/ReadyOS-C64/UltimateExperiments/tree/main/SuperEditor
