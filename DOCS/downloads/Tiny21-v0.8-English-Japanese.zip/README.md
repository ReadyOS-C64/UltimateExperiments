# C64 LLM - Little Language Model v0.8

This ZIP contains the console PRG and prebuilt models.

## Install on the C64 Ultimate

**You need a C64 Ultimate with 64 MHz turbo support, an enabled 16 MB REU,
the Command Interface enabled, and a USB drive.** In the Ultimate settings,
set Turbo Control to **C64U Turbo Registers** (also called **U64 Turbo
Registers** on some firmware). The program selects and verifies 64 MHz.

1. Unzip the archive. Copy `C64LLM.PRG`, `MODEL.BIN`, `C64PROGINFO.BIN`, and `E2JROMAJI.BIN` into `/USB1/TINY64-MODELS` in the Ultimate file browser.
2. In the Ultimate menu, select `C64LLM.PRG` and choose **Run**. The console
   starts with Tiny 2.1.
3. When the console is ready, select **F1** for Tiny 2.1, **F3** for C64PROGINFO, or **F5** for English to Japanese. Wait for **Model ready.** and
   check the **Model:** line. Then type your prompt and press **RETURN**.

The console loads each model from USB as needed and reuses a verified copy
in REU. Keep the drive connected for first use and after powering off.
If a model fails to load, check the filenames, folder, and settings above.

## Use the console

Use **DEL** to edit your question. Hold **RUN/STOP** during generation until
**Cancelled. Ready.** appears to interrupt it. Each completed question stays
on screen with its answer until you start typing the next one.

- **Tiny 2.1** answers short general questions. Try `what is 7 times 8`.
- **C64PROGINFO** is trained on C64 hardware, registers, BASIC V2, and 6502
  assembly. Try `what cpu does the c64 use`,
  `show basic code to clear the screen and print ready`, or
  `show assembler code to set border to red`. Code answers can span lines.
- **English to Japanese** translates short beginner English sentences to
  polite, spaced romaji. Press **F5**, then type `i ate an apple` and press
  **RETURN**. The expected translation is `watashi wa ringo o tabemashita`.
  Type the sentence directly. Try short everyday sentences in the model's
  beginner vocabulary. The model can miss words or conjugations.

Check unfamiliar technical details and generated code.

[Online guide and screenshots](https://readyos-c64.github.io/UltimateExperiments/tiny21/)

The port and its original models are MIT-licensed. The package includes notices for
[WollyMonjac’s original Tiny 2.1](https://github.com/WollyMonjac/Tiny-2.1)
and [jaydarkseed757’s c64-dungeon training tooling](https://github.com/jaydarkseed757/c64-dungeon).
